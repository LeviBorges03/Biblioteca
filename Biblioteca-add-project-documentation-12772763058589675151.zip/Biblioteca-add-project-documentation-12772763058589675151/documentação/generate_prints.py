from playwright.sync_api import sync_playwright

def run_cuj(page):
    page.goto("http://localhost:5239")
    page.wait_for_timeout(2000)

    # Screenshot of Index page
    page.screenshot(path="documentação/prints/index.png", full_page=True)
    page.wait_for_timeout(500)

    # Click on "Ver todo o catálogo" to expand search
    expand_btn = page.locator("#expandBtn")
    if expand_btn.is_visible():
        expand_btn.click()
        page.wait_for_timeout(1000)
        # Screenshot with expanded search
        page.screenshot(path="documentação/prints/index_expanded.png", full_page=True)

    # Click on a book to go to the book page
    book_link = page.locator(".livro-card-link").first
    if book_link.is_visible():
        book_link.click()
        page.wait_for_timeout(1000)
        # Screenshot of Book page
        page.screenshot(path="documentação/prints/livro.png", full_page=True)

    # Go back to index
    page.goto("http://localhost:5239")
    page.wait_for_timeout(1000)

    # Click on an author to go to the author page
    author_link = page.locator(".autor-link-hover").first
    if author_link.is_visible():
        author_link.click()
        page.wait_for_timeout(1000)
        # Screenshot of Author page
        page.screenshot(path="documentação/prints/autor.png", full_page=True)

if __name__ == "__main__":
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            record_video_dir="documentação/prints"
        )
        page = context.new_page()
        try:
            run_cuj(page)
        finally:
            context.close()
            browser.close()
